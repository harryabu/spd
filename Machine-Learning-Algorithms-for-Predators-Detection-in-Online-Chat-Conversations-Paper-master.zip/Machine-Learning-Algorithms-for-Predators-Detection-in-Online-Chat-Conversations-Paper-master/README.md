# Machine Learning Algorithms for Predators Detection in Online Chat Conversations
- ML project paper collaborted with Ken Lee and Romario Timothy Vaz 
1. This project uses Python 3.6.3,  install all libs in requirements.txt
2. Then start notebook via "jupyter notebook".
3. The data is available for download from [here](https://pan.webis.de/clef12/pan12-web/author-identification.html), unzip the zip files in /data/ such that the directory is as follows
	- /src
	- /data
		- /pan12-sexual-predator-identification-test-corpus-2012-05-21
		- /pan12-sexual-predator-identification-training-corpus-2012-05-01
